<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>PacMan</title>
    <link rel="stylesheet" href="/pacman/style.css" />
    <script src="/pacman/app.js" charset="utf-8"></script>
  </head>
  <body style="margin:0px;">
    <div class="overlay-screen" id="start-screen">
      <h1>PACMAN</h1>
      <h2 id="start-msg">Press ENTER to start</h2>
      <h2>Use arrow keys to move</h2>
    </div>
    <div class="game-container" style="width:100%;height:100%;">
      <div class="grid"></div>
      <h2>Score:<span id="score">0</span></h2>
    </div>
    <div class="overlay-screen" id="game-over-screen">
      <span>GAME OVER!</span>
    </div>
    <div class="overlay-screen" id="you-won-screen">
      <span>YOU WON!</span>
    </div>
  </body>
</html>
